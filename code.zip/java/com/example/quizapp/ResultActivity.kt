package com.example.quizapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_result.*

class ResultActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)

        // deactivate nav bar
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN

        // Store Username
        val username = intent.getStringExtra(Constants.USER_NAME)
        // Store Correct answers
        val correctAnswers = intent.getIntExtra(Constants.CORRECT_ANSWERS, 0)
        // Store total questions
        val totalQuestions = intent.getIntExtra(Constants.TOTAL_QUESTIONS, 0)

        // Set Message according to score obtained by the user
        var msg: String? = null

        // Calculate percentage
        val a = correctAnswers.toFloat()
        val b = totalQuestions.toFloat()
        val percentage: Float = (a / b) * 100.0f
        println(percentage)
        msg = when {
            (percentage <= 40.0f) -> "Practice makes a man perfect..."
            (percentage > 40.0f && percentage <= 70.0f) -> "Well Played!"
            else -> "Hey Congratulations!"
        }
        tv_message.text = msg

        // Set User Name
        tv_name.text = username

        // Set Score
        val score = "Your score is $correctAnswers out of $totalQuestions"
        tv_score.text = score

        // On pressing starts Main activity and finishes current activity
        btn_finish.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}