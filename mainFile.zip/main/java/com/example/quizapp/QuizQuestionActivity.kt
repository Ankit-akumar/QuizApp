package com.example.quizapp

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.activity_quiz_question.*

class QuizQuestionActivity : AppCompatActivity(), View.OnClickListener {

    // Username from main activity
    private var mUsername: String? = null

    // Stores Player's Score
    private var mCorrectAnswers = 0

    // Stores the current question number
    private var mCurrentPosition = 1

    // Array list of all the questions
    private var mQuestionList: ArrayList<Question>? = null

    // Stores the selected option
    private var mSelectedOptionPosition: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz_question)

        // Getting username form main activity ans setting mUsername variable
        mUsername = intent.getStringExtra(Constants.USER_NAME)

        // Get all the questions
        mQuestionList = Constants.getQuestions()

        // Set the current question
        setQuestion()

        tvOption1.setOnClickListener(this)
        tvOption2.setOnClickListener(this)
        tvOption3.setOnClickListener(this)
        tvOption4.setOnClickListener(this)
        btn_submit.setOnClickListener(this)
    }

    private fun setQuestion() {
        val question = mQuestionList!![mCurrentPosition - 1]

        defaultOptionsView()

        if (mCurrentPosition == mQuestionList!!.size) {
            btn_submit.text = "FINISH"
        } else {
            btn_submit.text = "SUBMIT"
        }

        // Setting up Progress bar
        ProgressBar.progress = mCurrentPosition
        val progressBarText = "$mCurrentPosition" + "/" + ProgressBar.max
        tvProgress.text = progressBarText

        // Setting the questions
        tvQuestion.text = question.question
        ivImage.setImageResource(question.image)
        tvOption1.text = question.option1
        tvOption2.text = question.option2
        tvOption3.text = question.option3
        tvOption4.text = question.option4
    }

    // Set the options
    private fun defaultOptionsView() {
        // Store all the options into an array list of textViews
        val options = ArrayList<TextView>()
        options.add(0, tvOption1)
        options.add(1, tvOption2)
        options.add(2, tvOption3)
        options.add(3, tvOption4)

        // Iterate through the list and set typeface and text color of each option to default
        for (option in options) {
            option.setTextColor(Color.parseColor("#7A8089"))
            option.typeface = Typeface.DEFAULT
            option.background = ContextCompat.getDrawable(
                this, R.drawable.default_option_bg,
            )
        }
    }

    // Overriding the function onClick to define its behaviour when any specific button is clicked
    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.tvOption1 -> {
                selectedOptionView(tvOption1, 1)
            }
            R.id.tvOption2 -> {
                selectedOptionView(tvOption2, 2)
            }
            R.id.tvOption3 -> {
                selectedOptionView(tvOption3, 3)
            }
            R.id.tvOption4 -> {
                selectedOptionView(tvOption4, 4)
            }
            R.id.btn_submit -> {
                // If user wants to skip the question
                if (mSelectedOptionPosition == 0) {            // 0 means none of the options were selected.
                    mCurrentPosition++                  // Go to the next question

                    when {
                        mCurrentPosition <= mQuestionList!!.size -> {     // If questions are left then set new question
                            setQuestion()
                        }
                        else -> {
                            // If questions end then finish the activity and move to result activity
                            val intent = Intent(this, ResultActivity::class.java)
                            // Sending username to Result Activity
                            intent.putExtra(Constants.USER_NAME, mUsername)
                            // Sending number of Correct Answers to Result Activity
                            intent.putExtra(Constants.CORRECT_ANSWERS, mCorrectAnswers)
                            // Sending number of Questions to Result Activity
                            intent.putExtra(Constants.TOTAL_QUESTIONS, mQuestionList!!.size)
                            // Start next activity
                            startActivity(intent)
                            // Finish the current activity
                            finish()
                        }
                    }
                } else {            // If some option was selected
                    val question =
                        mQuestionList?.get(mCurrentPosition - 1) // Get the current question object and store into question variable
                    if (question!!.correctAnswer != mSelectedOptionPosition) {   // If wrong option was selected
                        answerView(
                            mSelectedOptionPosition,
                            R.drawable.wrong_option_bg
                        )  // Set the wrong option background
                    } else {                 // If the correct answer was selected increment mCorrectAnswers
                        mCorrectAnswers++
                    }
                    answerView(
                        question.correctAnswer,
                        R.drawable.correct_option_bg
                    )   // Call the function to set the correct option background

                    // If this was the last question -> Set text on submit button to FINISH
                    if (mCurrentPosition == mQuestionList!!.size) {
                        btn_submit.text = "FINISH"
                    } else {                                        // Else set the text to NEXT
                        btn_submit.text = "NEXT"
                    }

                    /*
                    Set selected option again to zero in order to use it again for the next question.
                    Moreover this is checked at the beginning of this function and next question is
                    displayed only if this is set to zero.
                    */
                    mSelectedOptionPosition = 0
                }
            }
        }
    }

    // Sets green background to the correct option
    private fun answerView(answer: Int, drawableView: Int) {
        when (answer) {
            1 -> {
                tvOption1.background = ContextCompat.getDrawable(this, drawableView)
            }
            2 -> {
                tvOption2.background = ContextCompat.getDrawable(this, drawableView)
            }
            3 -> {
                tvOption3.background = ContextCompat.getDrawable(this, drawableView)
            }
            4 -> {
                tvOption4.background = ContextCompat.getDrawable(this, drawableView)
            }
        }
    }

    // Sets the typeface and text color of the selected option
    private fun selectedOptionView(tv: TextView, selectedOptionNumber: Int) {
        // First set all options to default
        defaultOptionsView()

        // Change the selected option number to the option selected
        mSelectedOptionPosition = selectedOptionNumber

        // Finally set the type face, text color and background
        tv.setTextColor(Color.parseColor("#363A43"))
        tv.setTypeface(tv.typeface, Typeface.BOLD)
        tv.background = ContextCompat.getDrawable(
            this, R.drawable.selected_option_bg,
        )
    }
}

