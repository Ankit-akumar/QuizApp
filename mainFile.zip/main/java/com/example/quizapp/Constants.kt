package com.example.quizapp

object Constants {

    const val USER_NAME: String = "user_name"
    const val TOTAL_QUESTIONS: String = "total_questions"
    const val CORRECT_ANSWERS: String = "correct_answers"

    fun getQuestions(): ArrayList<Question> {
        // An array of questions
        val questionsList = ArrayList<Question>()

        // 1st question
        val question1 = Question(
            1,
            "Grand Central Terminal, Park Avenue, New York is the world's",
            R.drawable.q1,
            "largest railway station",
            "highest railway station",
            "longest railway station",
            "None of the above",
            1
        )
        // Adding the question to the list
        questionsList.add(question1)

        val question2 = Question(
            2,
            "Entomology is the science that studies",
            R.drawable.q2,
            "Behavior of human beings",
            "Insects",
            "The origin and history of technical and scientific terms",
            "The formation of rocks",
            2
        )
        questionsList.add(question2)

        val question3 = Question(
            3,
            "Eritrea, which became the 182nd member of the UN in 1993, is in the continent of",
            R.drawable.q3,
            "Asia",
            "Africa",
            "Europe",
            "Australia",
            2
        )
        questionsList.add(question3)

        val question4 = Question(
            4,
            "Garampani sanctuary is located at",
            R.drawable.q4,
            "Junagarh, Gujarat",
            "Gangtok, Sikkim",
            "Kohima, Nagaland",
            "Diphu, Assam",
            4
        )
        questionsList.add(question4)

        val question5 = Question(
            5,
            "For which of the following disciplines is Nobel Prize awarded?",
            R.drawable.q5,
            "Physics and Chemistry",
            "Physiology or Medicine",
            "Literature, Peace and Economics",
            "All of the above",
            4
        )
        questionsList.add(question5)

        val question6 = Question(
            6,
            "Hitler party which came into power in 1933 is known as",
            R.drawable.q6,
            "Nazi Party",
            "Labour Party",
            "Democratic Party",
            "Ku-Klux-Klan",
            1
        )
        questionsList.add(question6)

        val question7 = Question(
            7,
            "Galileo was an Italian astronomer who",
            R.drawable.q7,
            "developed the telescope",
            "discovered four satellites of Jupiter",
            "discovered that the movement of pendulum produces a regular time measurement",
            "All of the above",
            4
        )
        questionsList.add(question7)

        val question8 = Question(
            8,
            "Golf player Vijay Singh belongs to which country?",
            R.drawable.q8,
            "USA",
            "Fiji",
            "India",
            "UK",
            2
        )
        questionsList.add(question8)

        val question9 = Question(
            9,
            "Each year World Red Cross and Red Crescent Day is celebrated on",
            R.drawable.q9,
            "May 8",
            "May 18",
            "June 8",
            "June 18",
            1
        )
        questionsList.add(question9)

        val question10 = Question(
            10,
            "Gravity setting chambers are used in industries to remove",
            R.drawable.q10,
            "SOx",
            "NOx",
            "suspended particulate matter",
            "CO",
            3
        )
        questionsList.add(question10)

        return questionsList
    }

}
